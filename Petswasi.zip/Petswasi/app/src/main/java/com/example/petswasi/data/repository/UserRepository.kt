package com.example.petswasi.data.repository

import com.example.petswasi.data.model.Donation
import com.example.petswasi.data.model.Message
import com.example.petswasi.data.model.User
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

class UserRepository {
    private val database = FirebaseDatabase.getInstance("https://petswasi-68ef9-default-rtdb.firebaseio.com/")
    private val usersRef = database.getReference("usuarios")

    fun createUsuario(uid: String, email: String, nombre: String, contrasena: String, rol: String = "usuario") {
        val nuevoUsuario = mapOf(
            "email" to email,
            "nombre" to nombre,
            "contrasena" to contrasena,
            "rol" to rol
        )
        usersRef.child(uid).setValue(nuevoUsuario)
    }

    fun enviarMensaje(fundacion: String, mensaje: String, usuarioNombre: String, remitente: String) {
        val mensajeData = mapOf(
            "fundacion" to fundacion,
            "mensaje" to mensaje,
            "usuario" to usuarioNombre,
            "remitente" to remitente,
            "fecha" to System.currentTimeMillis()
        )
        database.getReference("mensajes").push().setValue(mensajeData)
    }

    fun registrarDonacion(monto: String, usuarioNombre: String) {
        val donacionData = mapOf(
            "monto" to monto,
            "usuario" to usuarioNombre,
            "fecha" to System.currentTimeMillis()
        )
        database.getReference("donaciones").push().setValue(donacionData)
    }

    fun registrarAdopcion(petName: String, usuarioNombre: String) {
        val adopcionData = mapOf(
            "mascota" to petName,
            "usuario" to usuarioNombre,
            "fecha" to System.currentTimeMillis()
        )
        database.getReference("adopciones").push().setValue(adopcionData)
    }

    fun listenDonaciones(onUpdate: (List<Donation>) -> Unit) {
        database.getReference("donaciones").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Donation>()
                for (child in snapshot.children) {
                    child.getValue(Donation::class.java)?.let { list.add(it) }
                }
                onUpdate(list.reversed())
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun listenMensajes(fundacion: String, onUpdate: (List<Message>) -> Unit) {
        database.getReference("mensajes").orderByChild("fundacion").equalTo(fundacion)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<Message>()
                    for (child in snapshot.children) {
                        child.getValue(Message::class.java)?.copy(id = child.key ?: "")?.let { list.add(it) }
                    }
                    onUpdate(list.sortedByDescending { it.fecha })
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    suspend fun login(email: String, contrasena: String): User? {
        return try {
            withTimeoutOrNull(5000) {
                val snapshot = usersRef.get().await()
                for (userSnapshot in snapshot.children) {
                    val dbEmail = userSnapshot.child("email").getValue(String::class.java)
                    val dbPass = userSnapshot.child("contrasena").getValue(String::class.java)
                    val dbNombre = userSnapshot.child("nombre").getValue(String::class.java)
                    val dbRol = userSnapshot.child("rol").getValue(String::class.java) ?: "usuario"
                    
                    if (dbEmail?.trim() == email.trim() && dbPass == contrasena) {
                        return@withTimeoutOrNull User(userSnapshot.key ?: "", dbNombre ?: "Usuario", dbEmail, dbPass, dbRol)
                    }
                }
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
