package com.example.petswasi.data.model

data class User(
    val id: String = "",
    val nombre: String = "",
    val email: String = "",
    val contrasena: String = "",
    val rol: String = "usuario" // "usuario" o "fundacion"
)
