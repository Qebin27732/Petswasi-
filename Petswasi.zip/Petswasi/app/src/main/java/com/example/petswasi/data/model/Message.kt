package com.example.petswasi.data.model

data class Message(
    val id: String = "",
    val fundacion: String = "",
    val usuario: String = "",
    val mensaje: String = "",
    val remitente: String = "", // El nombre de quien envía el mensaje (puede ser el usuario o la fundación)
    val fecha: Long = 0
)
